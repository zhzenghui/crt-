//
//  StarWars.h
//  StarWars
//
//  Created by Artem Sidorenko on 10/20/15.
//  Copyright © 2015 Yalantis. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StarWars.
FOUNDATION_EXPORT double StarWarsVersionNumber;

//! Project version string for StarWars.
FOUNDATION_EXPORT const unsigned char StarWarsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StarWars/PublicHeader.h>


