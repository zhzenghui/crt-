#import <objc/objc-api.h>

OBJC_ROOT_CLASS
@interface GC @end
@implementation GC @end

// silence "no debug symbols in executable" warning
void foo(void) { }
